package com.example.we4care;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
public class Database extends SQLiteOpenHelper
{


    public Database(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, "we4care.db", factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String createTable = "CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, email TEXT, password TEXT)";
        db.execSQL(createTable);

        String createTableAppointments = "CREATE TABLE appointments (id INTEGER PRIMARY KEY AUTOINCREMENT, fullName TEXT, address TEXT, contact TEXT, fees TEXT, date TEXT, time TEXT)";
        db.execSQL(createTableAppointments);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS appointments");
        onCreate(db);
    }
    public void register(String username, String email, String password)
    {
        ContentValues cv = new ContentValues();
        cv.put("username",username);
        cv.put("email",email);
        cv.put("password",password);
        SQLiteDatabase db = getWritableDatabase();
        db.insert("users",null,cv);
        db.close();
    }

    public boolean checkLogin(String username, String password)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ? AND password = ?", new String[]{username, password});
        int count = ((Cursor) cursor).getCount();
        cursor.close();
        return count > 0;
    }

    public void insertAppointment(String fullName, String address, String contact, String fees, String date, String time)
    {
        ContentValues cv = new ContentValues();
        cv.put("fullName", fullName);
        cv.put("address", address);
        cv.put("contact", contact);
        cv.put("fees", fees);
        cv.put("date", date);
        cv.put("time", time);
        SQLiteDatabase db = getWritableDatabase();
        db.insert("appointments", null, cv);
        db.close();
    }
}
